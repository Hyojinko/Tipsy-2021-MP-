package com.example.drinkcheck;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class MainActivity extends AppCompatActivity {

    private TextView textView_Date;
    private DatePickerDialog.OnDateSetListener callbackMethod;
    public String fileName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.InitializeView();
        this.InitializeListener();
    }

    public void InitializeView()
    {
        textView_Date = (TextView)findViewById(R.id.textView);
    }
    public void InitializeListener()
    {
        callbackMethod = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth)
            {
                textView_Date.setText(year+"/"+(monthOfYear+1)+"/"+dayOfMonth);
                fileName = "tipsy"+Integer.toString(year)+Integer.toString(monthOfYear+1)+Integer.toString(dayOfMonth)+".txt";


//                PrintWriter outputStream=null;
//                try {
//                    outputStream=new PrintWriter(fileName);
//                }
//                catch(FileNotFoundException e) {
//                    System.out.println("error");
//                    System.exit(0);
//                }
//
//                int category=0;
//                for(int i=0;i<6;i++) {
//                    if(i%2==0) {
//                        outputStream.println(category);
//                        category++;
//                    }
//                    else {
//                        outputStream.println("*0");
//                    }
//
//                }
//
//                outputStream.close();

            }
        };

        Button btnDate = findViewById(R.id.btnDate);
        btnDate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                DatePickerDialog dialog = new DatePickerDialog(MainActivity.this, callbackMethod, 2021,1,1);
                dialog.show();
            }
        });
    }

}
